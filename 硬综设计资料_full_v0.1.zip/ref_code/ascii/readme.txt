### 使用方法

- 添加这两个文件
- 实例化instdec模块，输入为需要转换的32位的mips指令。
- 波形图中添加instdec输出变量ascii，右键该变量，选择Radix->ascii。