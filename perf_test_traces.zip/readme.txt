性能测试没有提供trace，这个是用demo改testbench生成的trace。
由于性能测试和运行的时间有关，其中涉及到时间的部分，trace比较会失败，忽略即可。

使用trace之前，还需要将

```
`define CONFREG_OPEN_TRACE   soc_lite.confreg.open_trace
```

改为

```
`define CONFREG_OPEN_TRACE   1'b1
```



注：这部分已经属于额外的东西了，所以出问题需要自己分析。比如要把testbench代码看懂。